# Pair-code

[![PAIR CODE](https://www.koyeb.com/static/images/deploy/button.svg)](https://app.koyeb.com/deploy?name=pair-code&type=git&repository=ROMEKTRICKS%2FPair-code&branch=main&builder=dockerfile&env%5B%5D=&ports=8000%3Bhttp%3B%2F)


[![Deploy to Koyeb](https://www.koyeb.com/static/images/deploy/button.svg)](https://app.koyeb.com/deploy?name=romek-md-pair-code&type=git&repository=ROMEKTRICKS%2FPair-code&branch=main&builder=dockerfile&env%5B%5D=&ports=8000%3Bhttp%3B%2F)
sh
